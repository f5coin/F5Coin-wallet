nohup java -cp nxt.jar:lib/*:conf nxt.Nxt >log_nohup.out &
