CP=conf/:classes/:lib/*
SP=src/java/

/bin/rm -rf nxt_db

/bin/mkdir -p classes/
javac -sourcepath $SP -classpath $CP -d classes/ src/java/nxt/*.java src/java/nxt/*/*.java -Xlint:unchecked || exit 1

/bin rm -f nxt.jar
jar cf nxt.jar -C classes . || exit 1
/bin/rm -rf classes

echo "F5Coin generated successfully"

